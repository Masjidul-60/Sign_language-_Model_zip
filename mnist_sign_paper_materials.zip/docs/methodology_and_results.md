# Methodology and Results Evidence

## Scope and evidence

This note was prepared only from the two supplied attachments: a Python model-definition fragment and a JSON capture of `model.summary()`. It separates directly observed configuration from derived arithmetic and from information that is not available. It is not evidence that the model was trained or evaluated.

## Model architecture

The supplied code defines a sequential convolutional neural network for single-channel images with input shape `28 × 28 × 1`:

1. `Conv2D`: 16 filters, `3 × 3` kernel, ReLU; valid padding is the Keras default.
2. `MaxPool2D`: `2 × 2`, `same` padding.
3. `Conv2D`: 32 filters, `3 × 3` kernel, ReLU; valid padding is the Keras default.
4. `MaxPool2D`: `2 × 2`, `same` padding.
5. `Flatten`.
6. `Dense`: 128 units, ReLU.
7. `Dropout`: rate `0.3`.
8. `Dense`: 25 units, softmax.

The captured summary reports 155,609 trainable parameters and zero non-trainable parameters. Output shapes and layer parameter counts are:

| Layer | Output shape (batch dimension omitted) | Parameters |
|---|---:|---:|
| Conv2D, 16 filters | `26 × 26 × 16` | 160 |
| MaxPooling2D | `13 × 13 × 16` | 0 |
| Conv2D, 32 filters | `11 × 11 × 32` | 4,640 |
| MaxPooling2D | `6 × 6 × 32` | 0 |
| Flatten | 1,152 | 0 |
| Dense, 128 units | 128 | 147,584 |
| Dropout | 128 | 0 |
| Dense, 25 units | 25 | 3,225 |
| **Total** |  | **155,609** |

## Compile configuration

The code compiles the model with:

- Optimizer: Adam (no explicit hyperparameters are provided, so framework defaults apply).
- Loss: sparse categorical cross-entropy.
- Metric: accuracy.

These are compile-time settings only. The supplied material does not show a call to `fit`, `evaluate`, or prediction code.

## Results that are actually available

The only reported result is the model summary: 155,609 total/trainable parameters, no non-trainable parameters, and the layer shapes/counts listed above. These are architecture statistics, not predictive-performance results.

No measured training accuracy, validation accuracy, test accuracy, loss, runtime, or statistical uncertainty is present in the attachments.

## Information required before making empirical claims

Obtain from the original experiment or document explicitly as not reported:

- Exact dataset name/source, version, license, class definitions, and label mapping. The filenames hint at a sign-language MNIST task but do not prove which dataset or variant was used.
- Number of examples per class and any class imbalance.
- Preprocessing, normalization, resizing, augmentation, and handling of invalid examples.
- Train/validation/test split sizes and method; confirm there is no leakage between splits.
- Epoch count, batch size, shuffle setting, callbacks, and stopping/checkpoint criteria.
- Random seeds, hardware, software/framework versions, and whether results are reproducible across runs.
- Training and validation curves, final test metrics, per-class results, confusion matrix, and evaluation procedure.
- Baselines and comparison protocol, if comparative claims are intended.

## Caution for paper drafting

Do not present the architecture summary as a classification-performance result. Do not infer the dataset, label semantics, preprocessing, training duration, or accuracy from the model name or output dimension. Add empirical claims only after the underlying run logs and dataset protocol have been verified.
